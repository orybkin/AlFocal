% y = ransacfitIdF(x) - ransac fit identity function y = x

% T. Pajdla, pajdla@cmp.felk.cvut.cz
% 2015-07-11
function y = ransacfitIdF(x)
y=x;


