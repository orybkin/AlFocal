% v = m2v(M) => vectorization of M: v = M(:)
%
% M = mutlidimensional matrix
% v = column vector

% pajdla@cvut.cz, 2016-04-24
function v = m2v(M)

v = M(:);
